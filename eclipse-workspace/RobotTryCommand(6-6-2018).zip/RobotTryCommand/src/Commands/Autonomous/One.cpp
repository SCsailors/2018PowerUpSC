#include "One.h"
#include "../../Robot.h"
#include <SmartDashBoard/SmartDashBoard.h>
#include <DriverStation.h>
#include "../DriveStraight.h"
#include "../ClawToggle.h"
#include "../MoveArm.h"
#include "../Turn.h"

One::One() {
	Robot::gyro.Reset();
	gamedata = frc::DriverStation::GetInstance().GetGameSpecificMessage();
	frc::SmartDashboard::PutString("GameData",gamedata);
	if (gamedata[1]=='L'){
		frc::SmartDashboard::PutString("AutoChosen","1L Scale");
		AddSequential(new DriveStraight(3,.8,true));
		AddParallel(new MoveArm(.5,.8,true));
		AddSequential(new Turn(45));
		AddSequential(new DriveStraight(1,.8,true));
		AddSequential(new ClawToggle());
		Wait(1);
		AddSequential(new DriveStraight(3,-.8,true));

	}
	else if (gamedata[0]=='L'){
		frc::SmartDashboard::PutString("AutoChosen","1L Switch");
		AddSequential(new DriveStraight(2,.8,true));
		AddParallel(new MoveArm(.5,.8,true));
		AddSequential(new Turn(90));
		AddSequential(new DriveStraight(.5,.8,true));
		AddSequential(new ClawToggle());
	}
	else{
		frc::SmartDashboard::PutString("AutoChosen","1 Default");
		AddSequential(new DriveStraight(2,.8,true));

	}
}
