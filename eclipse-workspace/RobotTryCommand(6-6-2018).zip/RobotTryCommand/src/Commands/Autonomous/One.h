#pragma once

#include <Commands/CommandGroup.h>

class One : public frc::CommandGroup {
public:
	One();
private:
	std::string gamedata;
};

