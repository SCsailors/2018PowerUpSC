//Add Don't Do options
#include "../Robot.h"
#include <SmartDashBoard/SmartDashBoard.h>
#include <DriverStation.h>
#include "Autonomous.h"
#include "DriveStraight.h"
#include "ClawToggle.h"
#include "MoveArm.h"
#include "Turn.h"


Autonomous::Autonomous(int which): frc::CommandGroup("Autonomous") {
	frc::SmartDashboard::PutNumber("Which",which);
	if (which==10){
		frc::SmartDashboard::PutString("AutoChosen","1L Scale");
		AddSequential(new DriveStraight(3,.8,true));
		AddParallel(new MoveArm(.5,.8,true));
		AddSequential(new Turn(45));
		AddSequential(new DriveStraight(1,.8,true));
		AddSequential(new ClawToggle());
		Wait(1);
		AddSequential(new DriveStraight(3,-.8,true));
		}
	else if (which==11){
		frc::SmartDashboard::PutString("AutoChosen","1L Switch");
		AddSequential(new DriveStraight(2,.8,true));
		AddParallel(new MoveArm(.5,.8,true));
		AddSequential(new Turn(90));
		AddSequential(new DriveStraight(.5,.8,true));
		AddSequential(new ClawToggle());
	}
	else if (which==12){
		frc::SmartDashboard::PutString("AutoChosen","1 Default");
		AddSequential(new DriveStraight(2,.8,true));

	}

	else if (which==20){
		frc::SmartDashboard::PutString("AutoChosen","2R");
		AddSequential(new MoveArm(.5,.8,true));
		AddSequential(new DriveStraight(1.5,.8,true));
		AddSequential(new ClawToggle());
	}
	else if (which==21){
		frc::SmartDashboard::PutString("AutoChosen","2L");
		AddSequential(new DriveStraight(1,.8,true));
		AddSequential(new Turn(-90));
		AddSequential(new DriveStraight(1,.8,true));
		AddSequential(new Turn(90));
		AddSequential(new MoveArm(.5,.8,true));
		AddSequential(new DriveStraight(1,.8,true));
		AddSequential(new ClawToggle());
	}
	else if (which==30){
		frc::SmartDashboard::PutString("AutoChosen","3R Scale");
		AddSequential(new DriveStraight(3,.8,true));
		AddParallel(new MoveArm(.5,.8,true));
		AddSequential(new Turn(-45));
		AddSequential(new DriveStraight(1,.8,true));
		AddSequential(new ClawToggle());
		Wait(1);
		AddSequential(new DriveStraight(3,-.8,true));
	}
	else if (which==31){
		frc::SmartDashboard::PutString("AutoChosen","3R Switch");
		AddSequential(new DriveStraight(2,.8,true));
		AddParallel(new MoveArm(.5,.8,true));
		AddSequential(new Turn(-90));
		AddSequential(new DriveStraight(.5,.8,true));
		AddSequential(new ClawToggle());
	}
	else if (which==32){
		frc::SmartDashboard::PutString("AutoChosen","3 Default");
		AddSequential(new DriveStraight(2,.8,true));
	}
	else if (which==0){
		frc::SmartDashboard::PutString("AutoChosen","Default");
		AddSequential(new DriveStraight(2,.8,true));
	}

}
