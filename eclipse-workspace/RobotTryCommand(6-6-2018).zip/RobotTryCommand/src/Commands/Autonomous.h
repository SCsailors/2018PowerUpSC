#pragma once

#include <Commands/CommandGroup.h>

class Autonomous : public frc::CommandGroup {
public:
	Autonomous(int which);
};

