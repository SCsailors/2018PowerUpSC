#include "Robot.h"
#include <CameraServer.h>
#include "Commands/Autonomous/One.h"

MyClaw Robot::claw;
DriveTrain Robot::drivetrain;
Joysticks Robot::joysticks;
Arm Robot::arm;
MyGyro Robot::gyro;
Winch Robot::winch;

void Robot::RobotInit() {
	CameraServer::GetInstance()->StartAutomaticCapture();
	autochoice.AddDefault("Just Drive Forward", new One());
	autochoice.AddObject("Left", new One());
	frc::SmartDashboard::PutData("Which Autonomous?",&autochoice);

}

void Robot::AutonomousInit(){
	autonomous.reset(autochoice.GetSelected());
	autonomous->Start();

}

void Robot::AutonomousPeriodic(){
	frc::Scheduler::GetInstance()->Run();
}

void Robot::TeleopInit(){
	autonomous->Cancel();

}

void Robot::TeleopPeriodic(){
	frc::Scheduler::GetInstance()->Run();
}

void Robot::TestPeriodic(){}


START_ROBOT_CLASS(Robot)
