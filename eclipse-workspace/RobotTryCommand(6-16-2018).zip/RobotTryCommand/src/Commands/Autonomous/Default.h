#pragma once

#include <Commands/CommandGroup.h>

class Default : public frc::CommandGroup {
public:
	Default();
};

