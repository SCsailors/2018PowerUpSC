#pragma once

#include <Commands/CommandGroup.h>

class Right : public frc::CommandGroup {
public:
	Right(bool scale, bool prioswitch);
};

