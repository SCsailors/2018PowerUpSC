#pragma once

#include <Commands/CommandGroup.h>

class Middle : public frc::CommandGroup {
public:
	Middle();
};

