#pragma once

#include <Commands/CommandGroup.h>

class Left : public frc::CommandGroup {
public:
	Left(bool scale, bool prioswitch);
};

